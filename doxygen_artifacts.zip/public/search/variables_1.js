var searchData=
[
  ['candidate_0',['candidate',['../structCandidateRelation.html#a9b2193d98403bb20365ebd1a7704be9b',1,'CandidateRelation::candidate()'],['../structProbabilityEngine_1_1Hypothesis.html#ab5f6dcc2873f69841b9883189658b493',1,'ProbabilityEngine::Hypothesis::candidate()']]],
  ['candidate_5fprobability_5fdebug_5fmessage_1',['candidate_probability_debug_message',['../classConsoleUI.html#ac6363021d1eafabcd70942acfbd751e6',1,'ConsoleUI']]],
  ['candidate_5frelations_2',['candidate_relations',['../structQuestionRow.html#a118089b1e3fe78c97220d0f38f81ff3a',1,'QuestionRow']]],
  ['candidates_5f_3',['candidates_',['../classDatasetReader.html#ab2c83e7007c92f10db18fdf555a834fd',1,'DatasetReader']]],
  ['candidates_5fcount_4',['candidates_count',['../structConsoleUI_1_1LoadedQuestionsParams.html#a181b9848ef1119d531639ab07f59669f',1,'ConsoleUI::LoadedQuestionsParams']]],
  ['consecutive_5fzero_5frounds_5',['consecutive_zero_rounds',['../structProbabilityEngine_1_1Hypothesis.html#a771bed6dcb665e5a4e99a589251ec956',1,'ProbabilityEngine::Hypothesis']]]
];
