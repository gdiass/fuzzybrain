var searchData=
[
  ['session_5fcontrol_5fmessage_0',['session_control_message',['../classConsoleUI.html#a7cb50141785d5e8a455901dd526c72fd',1,'ConsoleUI']]],
  ['starting_5fnew_5fsession_5fmessage_1',['starting_new_session_message',['../classConsoleUI.html#a235e292afaa3a64725899e26c62c262f',1,'ConsoleUI']]],
  ['strong_5fcandidate_5ffound_5fdebug_2',['strong_candidate_found_debug',['../classConsoleUI.html#a03eb9af2e7d8f1e333ac721cc9228b8d',1,'ConsoleUI']]],
  ['strong_5fcandidate_5fprobability_5fdebug_5fformat_3',['strong_candidate_probability_debug_format',['../classConsoleUI.html#a17c9fefc48b14909080b57f3cd895fe2',1,'ConsoleUI']]],
  ['strong_5fcandidates_5f_4',['strong_candidates_',['../classProbabilityEngine.html#a86302c6502d29c44a83a73056c1a1d77',1,'ProbabilityEngine']]],
  ['success_5fmessage_5',['success_message',['../classConsoleUI.html#ac4075d6400c93123398683cce5b930d7',1,'ConsoleUI']]],
  ['suggestion_5fmessage_6',['suggestion_message',['../classConsoleUI.html#a136541efe022baf0360458d112ff2aa9',1,'ConsoleUI']]]
];
