var searchData=
[
  ['candidate_2ecpp_0',['candidate.cpp',['../candidate_8cpp.html',1,'']]],
  ['candidate_2ehpp_1',['candidate.hpp',['../candidate_8hpp.html',1,'']]]
];
