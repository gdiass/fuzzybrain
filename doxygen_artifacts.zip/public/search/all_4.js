var searchData=
[
  ['fuzzybrain_20—_20plataforma_20de_20lógica_20difusa_0',['FuzzyBrain — Plataforma de Lógica Difusa',['../index.html',1,'']]]
];
