var searchData=
[
  ['reader_5f_0',['reader_',['../classEngine.html#a8f49ef0af890d9e65c0502684c6d636d',1,'Engine']]],
  ['relation_1',['relation',['../structCandidateRelation.html#a133c71e4ccc67c5dcdebacef300d9a3f',1,'CandidateRelation']]],
  ['resources_5fpath_2',['resources_path',['../classDatasetReader.html#a96123ec644bcd93b86739538ca895d70',1,'DatasetReader']]],
  ['rounds_5fwith_5fsame_5fcandidates_3',['rounds_with_same_candidates',['../structProbabilityEngine_1_1StrongCandidates.html#ad039966a9e2f9d590be98120da3612f9',1,'ProbabilityEngine::StrongCandidates']]]
];
