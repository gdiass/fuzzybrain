var searchData=
[
  ['welcome_5fmessage_0',['welcome_message',['../classConsoleUI.html#ad9a427804e44301b922178a5fbc497ac',1,'ConsoleUI']]]
];
