var searchData=
[
  ['text_5f_0',['text_',['../classCandidate.html#a97ab3d868c9a9115523d9a6015fe4ba9',1,'Candidate::text_()'],['../classQuestion.html#a09b25fe1131c9de7a8245e0f0513a555',1,'Question::text_()']]],
  ['threshold_1',['threshold',['../structProbabilityEngine_1_1StrongCandidates.html#a6c183b7aef0d354edda7a4797fd2b2e0',1,'ProbabilityEngine::StrongCandidates']]]
];
