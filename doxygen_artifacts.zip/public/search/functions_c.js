var searchData=
[
  ['update_5fprobabilities_0',['update_probabilities',['../classProbabilityEngine.html#a619ec5d1b693b8f0c3e32a2ea358be1f',1,'ProbabilityEngine']]],
  ['update_5fstrong_5fcandidates_1',['update_strong_candidates',['../classProbabilityEngine.html#a14129d4260ab52cfc2641fe67831ba5d',1,'ProbabilityEngine']]],
  ['utf8_5flanguage_5fsettings_2',['utf8_language_settings',['../classConsoleUI.html#ae6fac114667189449374e9d33d66ad25',1,'ConsoleUI']]]
];
