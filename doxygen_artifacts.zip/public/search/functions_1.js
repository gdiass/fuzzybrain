var searchData=
[
  ['datasetreader_0',['DatasetReader',['../classDatasetReader.html#abe60f4e763526e2ac9127d707662ce1b',1,'DatasetReader']]]
];
