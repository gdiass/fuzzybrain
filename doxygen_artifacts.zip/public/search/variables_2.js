var searchData=
[
  ['dataset_5ffile_5fname_0',['dataset_file_name',['../classEngine.html#a6825d4bce3121187d7a4c30789574127',1,'Engine']]],
  ['debug_5fmode_5f_1',['debug_mode_',['../classEngine.html#a9bc02d7f2792369708f0b8cc3058a9ed',1,'Engine::debug_mode_()'],['../classProbabilityEngine.html#aa4b5ef187c6aeb6f8ce8954a2486ba55',1,'ProbabilityEngine::debug_mode_()'],['../classSessionController.html#af1b2ce3c43ce4ab932d2b8446bf4573d',1,'SessionController::debug_mode_()']]]
];
