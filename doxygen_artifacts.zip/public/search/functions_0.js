var searchData=
[
  ['candidate_0',['Candidate',['../classCandidate.html#af91390b41dc6eca137f9422028aa92d8',1,'Candidate']]],
  ['consoleui_1',['ConsoleUI',['../classConsoleUI.html#a2bd8c90f3844d3e8699ddfdab841ba0b',1,'ConsoleUI']]]
];
