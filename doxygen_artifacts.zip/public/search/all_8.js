var searchData=
[
  ['load_5ffile_0',['load_file',['../classDatasetReader.html#ac255d86d1655015d3792289b743cf534',1,'DatasetReader']]],
  ['load_5fquestions_5fmessage_1',['load_questions_message',['../classConsoleUI.html#abbb21fe7e3d2f150ced71e424e8ca0d3',1,'ConsoleUI']]],
  ['loadedquestionsparams_2',['LoadedQuestionsParams',['../structConsoleUI_1_1LoadedQuestionsParams.html',1,'ConsoleUI']]]
];
