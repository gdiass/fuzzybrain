var searchData=
[
  ['give_5fup_5fmessage_0',['give_up_message',['../classConsoleUI.html#a5c6915bcc893bf97039bd24178289b7e',1,'ConsoleUI']]]
];
