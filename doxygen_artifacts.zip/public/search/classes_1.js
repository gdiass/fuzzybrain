var searchData=
[
  ['datasetreader_0',['DatasetReader',['../classDatasetReader.html',1,'']]]
];
