var searchData=
[
  ['dataset_5freader_2ecpp_0',['dataset_reader.cpp',['../dataset__reader_8cpp.html',1,'']]],
  ['dataset_5freader_2ehpp_1',['dataset_reader.hpp',['../dataset__reader_8hpp.html',1,'']]]
];
