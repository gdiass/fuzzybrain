var searchData=
[
  ['candidate_0',['Candidate',['../classCandidate.html',1,'']]],
  ['candidaterelation_1',['CandidateRelation',['../structCandidateRelation.html',1,'']]],
  ['consoleui_2',['ConsoleUI',['../classConsoleUI.html',1,'']]]
];
